#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import absolute_import

from .rgb_primaries import LCD_DISPLAYS_RGB_PRIMARIES

__all__ = ['LCD_DISPLAYS_RGB_PRIMARIES']
