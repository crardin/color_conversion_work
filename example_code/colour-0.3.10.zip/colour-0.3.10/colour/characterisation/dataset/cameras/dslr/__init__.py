#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import absolute_import

from .spectral_sensitivities import DSLR_CAMERAS_RGB_SPECTRAL_SENSITIVITIES

__all__ = ['DSLR_CAMERAS_RGB_SPECTRAL_SENSITIVITIES']
