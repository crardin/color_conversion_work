API Reference
=============

Contents:

.. toctree::
   :titlesonly:

   colour

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

