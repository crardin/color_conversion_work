colour\.biochemistry\.michaelis\_menten Module
==============================================

.. automodule:: colour.biochemistry.michaelis_menten
    :members:
    :undoc-members:
    :show-inheritance:
