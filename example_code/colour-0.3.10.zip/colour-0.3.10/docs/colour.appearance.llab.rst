colour\.appearance\.llab Module
===============================

.. automodule:: colour.appearance.llab
    :members:
    :undoc-members:
    :show-inheritance:
