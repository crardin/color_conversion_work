colour\.adaptation\.cmccat2000 Module
=====================================

.. automodule:: colour.adaptation.cmccat2000
    :members:
    :undoc-members:
    :show-inheritance:
