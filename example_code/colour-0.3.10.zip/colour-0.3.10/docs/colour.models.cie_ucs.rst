colour\.models\.cie\_ucs Module
===============================

.. automodule:: colour.models.cie_ucs
    :members:
    :undoc-members:
    :show-inheritance:
