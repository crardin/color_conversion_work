colour\.constants\.common Module
================================

.. automodule:: colour.constants.common
    :members:
    :undoc-members:
    :show-inheritance:
