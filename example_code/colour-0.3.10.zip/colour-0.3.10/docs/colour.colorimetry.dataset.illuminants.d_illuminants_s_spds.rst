colour\.colorimetry\.dataset\.illuminants\.d\_illuminants\_s\_spds Module
=========================================================================

.. automodule:: colour.colorimetry.dataset.illuminants.d_illuminants_s_spds
    :members:
    :undoc-members:
    :show-inheritance:
