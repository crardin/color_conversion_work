colour\.characterisation\.dataset\.displays\.crt Package
========================================================

Sub-Modules
-----------

.. toctree::

   colour.characterisation.dataset.displays.crt.rgb_primaries

Module Contents
---------------

.. automodule:: colour.characterisation.dataset.displays.crt
    :members:
    :undoc-members:
    :show-inheritance:
