colour\.corresponding Package
=============================

Sub-Packages
------------

.. toctree::

    colour.corresponding.dataset

Sub-Modules
-----------

.. toctree::

   colour.corresponding.prediction

Module Contents
---------------

.. automodule:: colour.corresponding
    :members:
    :undoc-members:
    :show-inheritance:
