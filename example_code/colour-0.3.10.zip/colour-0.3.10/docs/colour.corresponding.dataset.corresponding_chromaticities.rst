colour\.corresponding\.dataset\.corresponding\_chromaticities Module
====================================================================

.. automodule:: colour.corresponding.dataset.corresponding_chromaticities
    :members:
    :undoc-members:
    :show-inheritance:
