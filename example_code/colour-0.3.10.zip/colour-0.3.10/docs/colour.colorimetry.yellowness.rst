colour\.colorimetry\.yellowness Module
======================================

.. automodule:: colour.colorimetry.yellowness
    :members:
    :undoc-members:
    :show-inheritance:
