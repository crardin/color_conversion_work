colour\.colorimetry\.dominant Module
====================================

.. automodule:: colour.colorimetry.dominant
    :members:
    :undoc-members:
    :show-inheritance:
