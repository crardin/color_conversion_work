colour\.adaptation\.cie1994 Module
==================================

.. automodule:: colour.adaptation.cie1994
    :members:
    :undoc-members:
    :show-inheritance:
