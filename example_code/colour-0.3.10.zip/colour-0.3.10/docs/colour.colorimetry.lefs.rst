colour\.colorimetry\.lefs Module
================================

.. automodule:: colour.colorimetry.lefs
    :members:
    :undoc-members:
    :show-inheritance:
