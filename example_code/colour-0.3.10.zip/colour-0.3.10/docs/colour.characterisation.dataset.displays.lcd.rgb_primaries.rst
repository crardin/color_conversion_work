colour\.characterisation\.dataset\.displays\.lcd\.rgb\_primaries Module
=======================================================================

.. automodule:: colour.characterisation.dataset.displays.lcd.rgb_primaries
    :members:
    :undoc-members:
    :show-inheritance:
