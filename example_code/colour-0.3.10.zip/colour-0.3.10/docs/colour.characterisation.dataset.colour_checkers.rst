colour\.characterisation\.dataset\.colour\_checkers Package
===========================================================

Sub-Modules
-----------

.. toctree::

   colour.characterisation.dataset.colour_checkers.chromaticity_coordinates
   colour.characterisation.dataset.colour_checkers.spds

Module Contents
---------------

.. automodule:: colour.characterisation.dataset.colour_checkers
    :members:
    :undoc-members:
    :show-inheritance:
