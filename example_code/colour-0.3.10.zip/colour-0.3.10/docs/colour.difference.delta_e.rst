colour\.difference\.delta\_e Module
===================================

.. automodule:: colour.difference.delta_e
    :members:
    :undoc-members:
    :show-inheritance:
