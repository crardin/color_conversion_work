colour\.algebra\.random Module
==============================

.. automodule:: colour.algebra.random
    :members:
    :undoc-members:
    :show-inheritance:
