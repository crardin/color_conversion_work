colour\.models\.cie\_lab Module
===============================

.. automodule:: colour.models.cie_lab
    :members:
    :undoc-members:
    :show-inheritance:
