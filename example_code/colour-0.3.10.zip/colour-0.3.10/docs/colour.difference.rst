colour\.difference Package
==========================

Sub-Modules
-----------

.. toctree::

   colour.difference.delta_e
   colour.difference.delta_e_luo2006

Module Contents
---------------

.. automodule:: colour.difference
    :members:
    :undoc-members:
    :show-inheritance:
