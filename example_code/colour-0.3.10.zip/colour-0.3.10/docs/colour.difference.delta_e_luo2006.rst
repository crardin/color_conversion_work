colour\.difference\.delta\_e\_luo2006 Module
============================================

.. automodule:: colour.difference.delta_e_luo2006
    :members:
    :undoc-members:
    :show-inheritance:
