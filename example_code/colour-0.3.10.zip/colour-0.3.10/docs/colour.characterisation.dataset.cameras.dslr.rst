colour\.characterisation\.dataset\.cameras\.dslr Package
========================================================

Sub-Modules
-----------

.. toctree::

   colour.characterisation.dataset.cameras.dslr.spectral_sensitivities

Module Contents
---------------

.. automodule:: colour.characterisation.dataset.cameras.dslr
    :members:
    :undoc-members:
    :show-inheritance:
