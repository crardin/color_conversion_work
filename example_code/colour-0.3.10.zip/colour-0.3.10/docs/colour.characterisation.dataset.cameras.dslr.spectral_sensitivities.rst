colour\.characterisation\.dataset\.cameras\.dslr\.spectral\_sensitivities Module
================================================================================

.. automodule:: colour.characterisation.dataset.cameras.dslr.spectral_sensitivities
    :members:
    :undoc-members:
    :show-inheritance:
