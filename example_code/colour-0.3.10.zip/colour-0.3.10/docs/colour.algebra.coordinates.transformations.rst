colour\.algebra\.coordinates\.transformations Module
====================================================

.. automodule:: colour.algebra.coordinates.transformations
    :members:
    :undoc-members:
    :show-inheritance:
