colour\.colorimetry\.dataset\.lefs Module
=========================================

.. automodule:: colour.colorimetry.dataset.lefs
    :members:
    :undoc-members:
    :show-inheritance:
