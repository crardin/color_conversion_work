colour\.adaptation\.fairchild1990 Module
========================================

.. automodule:: colour.adaptation.fairchild1990
    :members:
    :undoc-members:
    :show-inheritance:
