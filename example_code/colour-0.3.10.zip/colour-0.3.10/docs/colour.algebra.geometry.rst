colour\.algebra\.geometry Module
================================

.. automodule:: colour.algebra.geometry
    :members:
    :undoc-members:
    :show-inheritance:
