colour\.algebra Package
=======================

Sub-Packages
------------

.. toctree::

    colour.algebra.coordinates

Sub-Modules
-----------

.. toctree::

   colour.algebra.extrapolation
   colour.algebra.geometry
   colour.algebra.interpolation
   colour.algebra.matrix
   colour.algebra.random

Module Contents
---------------

.. automodule:: colour.algebra
    :members:
    :undoc-members:
    :show-inheritance:
