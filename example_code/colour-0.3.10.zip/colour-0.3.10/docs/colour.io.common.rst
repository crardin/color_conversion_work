colour\.io\.common Module
=========================

.. automodule:: colour.io.common
    :members:
    :undoc-members:
    :show-inheritance:
