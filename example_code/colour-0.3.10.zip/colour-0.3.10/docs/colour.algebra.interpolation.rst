colour\.algebra\.interpolation Module
=====================================

.. automodule:: colour.algebra.interpolation
    :members:
    :undoc-members:
    :show-inheritance:
