colour\.appearance\.atd95 Module
================================

.. automodule:: colour.appearance.atd95
    :members:
    :undoc-members:
    :show-inheritance:
