colour\.characterisation\.dataset\.colour\_checkers\.chromaticity\_coordinates Module
=====================================================================================

.. automodule:: colour.characterisation.dataset.colour_checkers.chromaticity_coordinates
    :members:
    :undoc-members:
    :show-inheritance:
