colour\.corresponding\.prediction Module
========================================

.. automodule:: colour.corresponding.prediction
    :members:
    :undoc-members:
    :show-inheritance:
