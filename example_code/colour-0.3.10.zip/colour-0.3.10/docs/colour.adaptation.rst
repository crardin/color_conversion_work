colour\.adaptation Package
==========================

Sub-Packages
------------

.. toctree::

    colour.adaptation.dataset

Sub-Modules
-----------

.. toctree::

   colour.adaptation.cie1994
   colour.adaptation.cmccat2000
   colour.adaptation.fairchild1990
   colour.adaptation.vonkries

Module Contents
---------------

.. automodule:: colour.adaptation
    :members:
    :undoc-members:
    :show-inheritance:
