colour\.appearance\.hunt Module
===============================

.. automodule:: colour.appearance.hunt
    :members:
    :undoc-members:
    :show-inheritance:
