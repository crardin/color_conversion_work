colour\.appearance\.ciecam02 Module
===================================

.. automodule:: colour.appearance.ciecam02
    :members:
    :undoc-members:
    :show-inheritance:
