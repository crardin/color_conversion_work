colour\.colorimetry\.dataset\.illuminants\.chromaticity\_coordinates Module
===========================================================================

.. automodule:: colour.colorimetry.dataset.illuminants.chromaticity_coordinates
    :members:
    :undoc-members:
    :show-inheritance:
