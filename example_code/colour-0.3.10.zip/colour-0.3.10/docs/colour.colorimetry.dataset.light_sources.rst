colour\.colorimetry\.dataset\.light\_sources Package
====================================================

Sub-Modules
-----------

.. toctree::

   colour.colorimetry.dataset.light_sources.chromaticity_coordinates
   colour.colorimetry.dataset.light_sources.spds

Module Contents
---------------

.. automodule:: colour.colorimetry.dataset.light_sources
    :members:
    :undoc-members:
    :show-inheritance:
