colour\.characterisation\.dataset\.displays\.lcd Package
========================================================

Sub-Modules
-----------

.. toctree::

   colour.characterisation.dataset.displays.lcd.rgb_primaries

Module Contents
---------------

.. automodule:: colour.characterisation.dataset.displays.lcd
    :members:
    :undoc-members:
    :show-inheritance:
