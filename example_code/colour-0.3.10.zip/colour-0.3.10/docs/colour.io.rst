colour\.io Package
==================

Sub-Modules
-----------

.. toctree::

   colour.io.common
   colour.io.ies_tm2714
   colour.io.image
   colour.io.tabular
   colour.io.xrite

Module Contents
---------------

.. automodule:: colour.io
    :members:
    :undoc-members:
    :show-inheritance:
