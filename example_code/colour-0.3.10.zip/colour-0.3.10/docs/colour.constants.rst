colour\.constants Package
=========================

Sub-Modules
-----------

.. toctree::

   colour.constants.cie
   colour.constants.codata
   colour.constants.common

Module Contents
---------------

.. automodule:: colour.constants
    :members:
    :undoc-members:
    :show-inheritance:
