colour\.colorimetry\.photometry Module
======================================

.. automodule:: colour.colorimetry.photometry
    :members:
    :undoc-members:
    :show-inheritance:
