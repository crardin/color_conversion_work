colour\.characterisation\.cameras Module
========================================

.. automodule:: colour.characterisation.cameras
    :members:
    :undoc-members:
    :show-inheritance:
