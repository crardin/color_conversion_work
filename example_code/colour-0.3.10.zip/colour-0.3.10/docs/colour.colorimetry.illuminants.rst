colour\.colorimetry\.illuminants Module
=======================================

.. automodule:: colour.colorimetry.illuminants
    :members:
    :undoc-members:
    :show-inheritance:
