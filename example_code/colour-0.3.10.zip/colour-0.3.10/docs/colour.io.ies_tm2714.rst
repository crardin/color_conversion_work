colour\.io\.ies\_tm2714 Module
==============================

.. automodule:: colour.io.ies_tm2714
    :members:
    :undoc-members:
    :show-inheritance:
