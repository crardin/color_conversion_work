colour\.adaptation\.dataset\.cat Module
=======================================

.. automodule:: colour.adaptation.dataset.cat
    :members:
    :undoc-members:
    :show-inheritance:
