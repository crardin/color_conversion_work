colour\.colorimetry\.dataset Package
====================================

Sub-Packages
------------

.. toctree::

    colour.colorimetry.dataset.illuminants
    colour.colorimetry.dataset.light_sources

Sub-Modules
-----------

.. toctree::

   colour.colorimetry.dataset.cmfs
   colour.colorimetry.dataset.lefs

Module Contents
---------------

.. automodule:: colour.colorimetry.dataset
    :members:
    :undoc-members:
    :show-inheritance:
