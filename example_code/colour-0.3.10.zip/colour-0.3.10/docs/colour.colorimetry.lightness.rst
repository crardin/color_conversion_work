colour\.colorimetry\.lightness Module
=====================================

.. automodule:: colour.colorimetry.lightness
    :members:
    :undoc-members:
    :show-inheritance:
