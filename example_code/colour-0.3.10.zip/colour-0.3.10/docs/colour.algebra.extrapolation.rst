colour\.algebra\.extrapolation Module
=====================================

.. automodule:: colour.algebra.extrapolation
    :members:
    :undoc-members:
    :show-inheritance:
